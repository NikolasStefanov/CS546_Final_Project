const restaurantData = require('./restaurants');
const reviewData = require('./reviews');

module.exports = {
    restaurants: restaurantData,
    reviews: reviewData
};