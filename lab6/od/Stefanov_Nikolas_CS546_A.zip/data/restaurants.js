const mongoCollections = require('../config/mongoCollections');
const restaurants = mongoCollections.restaurants;
let { ObjectId } = require('mongodb');

async function create(name, location, phoneNumber, website, priceRange, cuisines, serviceOptions) {
    //Error Check is in route

    //Real Function
    let newRestaurant = {
        name: name,
        location: location,
        phoneNumber: phoneNumber,
        website: website,
        priceRange: priceRange,
        cuisines: cuisines,
        overallRating: 0,
        serviceOptions: serviceOptions,
        reviews: []
    };

    const restaurantCollection = await restaurants();

    const restaurantInfo = await restaurantCollection.insertOne(newRestaurant);
    if (restaurantInfo.insertedCount === 0) {
        console.log("there")
        throw 'Could not add restaurant';
    }
    const newId = restaurantInfo.insertedId;
    const restaurant = await get(newId);
    return restaurant;
}

async function getAll() {
    //Real Function
    const restaurantCollection = await restaurants();

    const restaurantList = await restaurantCollection.find({}, { projection: { _id: 1, name: 1 } }).toArray();

    return restaurantList;
}

async function get(id) {
    //Error Check in route
    //Real Function
    const restaurantCollection = await restaurants();
    const restaurant = await restaurantCollection.findOne({ _id: id });
    if (restaurant === null) throw 'Error: No restaurant with that id';
    return restaurant;
}

async function remove(id) {
    //Error Check

    //Real Function
    const restaurantCollection = await restaurants();
    const deletionInfo = await restaurantCollection.deleteOne({ _id: id });

    if (deletionInfo.deletedCount === 0) {
        throw `Could not delete restaurant with id of ${id}`;
    }
    return { deleted: true };
}

async function update(id, name, location, phoneNumber, website, priceRange, cuisines, serviceOptions) {
    //Error Check is in route
    //Real Function
    const restaurantCollection = await restaurants();
    const restaurant = await restaurantCollection.findOne({ _id: id });
    if (restaurant === null) throw 'Error: No restaurant with that id';
    const updatedRestaurant = {
        _id: id,
        name: name,
        location: location,
        phoneNumber: phoneNumber,
        website: website,
        priceRange: priceRange,
        cuisines: cuisines,
        overallRating: restaurant.overallRating,
        serviceOptions: serviceOptions,
        reviews: restaurant.reviews
    };
    const updatedInfo = await restaurantCollection.replaceOne(
        { _id: id },
        updatedRestaurant
    );
    if (updatedInfo.modifiedCount === 0) {
        throw 'Error: Could not update restraurant successfully';
    }
    return updatedRestaurant
}

module.exports = {
    create,
    getAll,
    get,
    remove,
    update
}

