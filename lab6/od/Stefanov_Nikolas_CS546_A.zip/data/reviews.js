const mongoCollections = require('../config/mongoCollections');
const restaurants = mongoCollections.restaurants;
let { ObjectId } = require('mongodb');

async function create(id, title, reviewer, rating, dateOfReview, review) {
    const restaurantCollection = await restaurants();
    const curRestaurant = await restaurantCollection.findOne({ _id: id });
    if (curRestaurant === null) throw 'Error: No restaurant with that id';

    let newID = new ObjectId;

    let newReview = {
        _id: newID,
        title: title,
        reviewer: reviewer,
        rating: rating,
        dateOfReview: dateOfReview,
        review: review
    }

    let reviewArr = curRestaurant.reviews
    reviewArr.push(newReview)
    let total = 0
    for (let rev of reviewArr) {
        total = total + rev.rating
    }
    let average = total / (reviewArr.length)
    if (average % 1 !== 0) {
        average = parseFloat((Math.round(average * 100) / 100).toFixed(2));
    }

    const updatedRestaurant = {
        name: curRestaurant.name,
        location: curRestaurant.location,
        phoneNumber: curRestaurant.phoneNumber,
        website: curRestaurant.website,
        priceRange: curRestaurant.priceRange,
        cuisines: curRestaurant.cuisines,
        overallRating: average,
        serviceOptions: curRestaurant.serviceOptions,
        reviews: reviewArr
    };

    const updatedInfo = await restaurantCollection.replaceOne(
        { _id: id },
        updatedRestaurant
    );
    if (updatedInfo.modifiedCount === 0) {
        throw 'Error: Could not update restraurant successfully';
    }

    return updatedRestaurant
}

async function getRestaurant(id) {
    const restaurantCollection = await restaurants();
    const restaurant = await restaurantCollection.findOne({ _id: id });
    if (restaurant === null) throw 'Error: No restaurant with that id';
    return restaurant.reviews
}

async function getReview(reviewId) {
    const restaurantCollection = await restaurants();
    let bool = false
    let retReview = {}
    const restaurantList = await restaurantCollection.find({}).toArray()
    for (let restaurant of restaurantList) {
        for (let review of restaurant.reviews) {
            if (review._id.toString() === reviewId.toString()) {
                retReview = review
                bool = true
            }
        }
    }
    if (!bool) {
        throw "Error: Not found"
    }
    return retReview
}

async function remove(reviewId) {
    const restaurantCollection = await restaurants();
    let bool = false
    let retRestaurant = 0
    const restaurantList = await restaurantCollection.find({}).toArray()
    for (let restaurant of restaurantList) {
        for (let review of restaurant.reviews) {
            if (review._id.toString() === reviewId.toString()) {
                bool = true
                retRestaurant = restaurant
            }
        }
    }
    if (!bool) {
        throw "Error: Not found"
    }
    const theRestaurant = await restaurantCollection.findOne({ _id: retRestaurant._id });
    let reviewArr = theRestaurant.reviews
    let count = 0
    for (let element of reviewArr) {
        if (element._id.toString() === reviewId.toString()) {
            break
        }
        count = count + 1
    }
    reviewArr.splice(count, 1);
    let total = 0
    for (let rev of reviewArr) {
        total = total + rev.rating
    }
    let average = total / (reviewArr.length)
    if (average % 1 !== 0) {
        average = parseFloat((Math.round(average * 100) / 100).toFixed(2));
    }
    const updatedRestaurant = {
        name: theRestaurant.name,
        location: theRestaurant.location,
        phoneNumber: theRestaurant.phoneNumber,
        website: theRestaurant.website,
        priceRange: theRestaurant.priceRange,
        cuisines: theRestaurant.cuisines,
        overallRating: average,
        serviceOptions: theRestaurant.serviceOptions,
        reviews: reviewArr
    };
    const updatedInfo = await restaurantCollection.replaceOne(
        { _id: retRestaurant._id },
        updatedRestaurant
    );
    if (updatedInfo.modifiedCount === 0) {
        throw 'Error: Could not update restraurant successfully';
    }
    return { "reviewId": reviewId, "deleted": true }
}

module.exports = {
    create,
    getRestaurant,
    getReview,
    remove
}