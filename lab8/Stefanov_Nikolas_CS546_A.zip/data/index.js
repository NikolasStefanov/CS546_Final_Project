module.exports = {
    search: require('./search'),
    characters: require('./characters')
};